from flask import Flask, render_template, url_for, request, redirect
app = Flask(__name__)                                               #create the Flask app

@app.route('/')
def track_trace():
   return render_template('SquashBookings.html')

@app.route('/register',methods = ['POST', 'GET'])
def register():
    if request.method == 'POST':
        register = request.form
        return render_template("signup.html",result = register)
    else:
        return ('Error! There is an error creating a new account')

@app.route('/register/return-home',methods = ['POST', 'GET'])
def return_home():
    if request.method == 'POST':
      return redirect(url_for('track_trace'))

if __name__ == '__main__':
   app.run(debug=True, port=80)

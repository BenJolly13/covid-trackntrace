from flask import Flask
import pymysql

dbconn=pymysql.connect('3.82.228.10','BenJolly', 'Jennifer13', 'Squash')

curs=dbconn.cursor()
forename="John"
surname="Cena"
phone="07739794333"
email="johncena@outlook.co.uk"
username="JohnC"
passwd="yoyoyoyo12"
curs.execute("""insert into registration values("%s","%s","%s","%s","%s","%s")"""%(forename,surname,phone,email,username,passwd))
dbconn.commit()

dbconn.close()

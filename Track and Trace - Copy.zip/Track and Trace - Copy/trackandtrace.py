from flask import Flask, render_template, url_for, request, redirect
import pymysql

app = Flask(__name__, static_folder="static", static_url_path="")

@app.route('/')
def track_trace():
   return render_template('Homepage.html')

try:
    @app.route('/login',methods = ['POST', 'GET'])
    def booking():
        if request.method == 'POST': 
            print(request.form)
            username = request.form['uname']
            passwd = request.form['passwd']

            dbconn=pymysql.connect('3.82.228.10','BenJolly', 'Jennifer13', 'Squash')
            curs=dbconn.cursor()
            curs.execute("""insert into login values("%s","%s")"""%(username,passwd))
            dbconn.commit()
            dbconn.close()

            return render_template("purpose-selection.html",result = booking)
        else:
            return redirect(url_for('track_trace'))
    
    try:
        @app.route('/login/purpose',methods = ['POST', 'GET'])
        def purpose():
            if request.method == 'POST':
                return render_template('DateSelect.html')

        @app.route('/login/purpose/booking',methods = ['POST', 'GET'])
        def thanks():
            if request.method == 'POST':
                print(request.form)
                court = request.form['court']
                date = request.form['bookings']
                arrival = request.form['arrival']
                departure = request.form['departure']

                dbconn=pymysql.connect('3.82.228.10','BenJolly', 'Jennifer13', 'Squash')
                curs=dbconn.cursor()
                curs.execute("""insert into booking values("%s","%s","%s","%s")"""%(court,date,arrival,departure))
                dbconn.commit()
                dbconn.close()

                return render_template("Thanks.html",result = thanks)
            else:
                return ('Error! There is an error processing your time details')

        @app.route('/login/purpose/booking/thanks',methods = ['POST', 'GET'])
        def complete():
            if request.method == 'POST':
                return redirect(url_for('track_trace'))
            else:
                return('Oops! Error has occured')
    except:
        pass

    try:
        @app.route('/login/covid', methods = ['POST', 'GET'])
        def covid():
            if request.method == 'POST':
                return render_template('covid.html')
            else:
                return('Oops! Error has occured')

        @app.route('/login/covid/select', methods = ['POST' ,'GET'])
        def select():
            if request.method == 'POST':
                return render_template('covid-submission.html')
            else:
                return('Oops! Error has occured')

        @app.route('/login/covid/select/submission', methods = ['POST' ,'GET'])
        def submission():
            if request.method == 'POST':
                return redirect(url_for('track_trace'))
            else:
                return('Oops! Error has occured')
    except:
        pass

except:
    pass

try:
    @app.route('/sign-up',methods = ['POST', 'GET'])
    def register():
        if request.method == 'POST':
            register = request.form
            return render_template("signup.html",result = register)
        else:
            return ('Error! There is an error creating a new account')

    @app.route('/sign-up/register',methods = ['POST', 'GET'])
    def return_home():
        if request.method == 'POST':
            print(request.form)
            forename = request.form['fname']
            surname = request.form['sname']
            phone = request.form['phone']
            email = request.form['email']
            uname = request.form['uname']
            password = request.form['passwd']

            dbconn=pymysql.connect('3.82.228.10','BenJolly', 'Jennifer13', 'Squash')
            curs=dbconn.cursor()
            curs.execute("""insert into registration values("%s","%s","%s","%s","%s","%s")"""%(forename,surname,phone,email,uname,password))
            dbconn.commit()
            dbconn.close()

            return render_template("completed-registration.html", result = return_home)
        else:
            return ('Error! There is an error processing your time details')

    @app.route('/sign-up/register/complete', methods = ['POST','GET'])
    def success():
        if request.method == 'POST':
            return redirect(url_for('track_trace'))
        else:
            return ('Oops! Error has occured.')
except:
    pass

if __name__ == '__main__':
   app.run(debug=True, port=80)
